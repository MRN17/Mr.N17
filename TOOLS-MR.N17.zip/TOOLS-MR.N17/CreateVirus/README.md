# CreaterVirus
# ____________

<br>

# INSTALLING
```
apt update && apt upgrade
apt install python2
pip2 install mechanize
```
# USAGE
```
python2 creater.py
```

<br>

# IMAGE
--------------------------------
<img src="/.image/Creater.png"/>
