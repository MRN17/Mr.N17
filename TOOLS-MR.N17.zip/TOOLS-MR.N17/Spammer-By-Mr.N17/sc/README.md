[PHP][TOOL][SPAM SMS]

Requirement:

Installed php

Connection Internet

Just That ;)

Android:
Must installed Termux, and installed php (pkg install php)

Windows(PC):
Must installed XAMPP

Happy Spamming!
